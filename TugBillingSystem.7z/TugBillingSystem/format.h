#ifndef FORMAT_H
#define FORMAT_H


#include <QJsonObject>

#pragma once

namespace Format{
QJsonObject QStringToJson(QString jsonString);
QString JsonToQString(QJsonObject jsonObject);

QString getOrderStatus(QString auditState, QString checkState, QString isrespagree);
}


#endif // FORMAT_H
