#include "login.h"

#include <QApplication>

//以下头文件引入后均作测试用途
#include "samainwindow.h"
#include "tcmainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login w;
//    SAMainWindow w("tim");
//    TCMainWindow w("李四", 0);
    w.show();
    return a.exec();
}
