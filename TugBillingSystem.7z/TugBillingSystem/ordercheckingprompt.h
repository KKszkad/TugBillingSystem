#ifndef ORDERCHECKINGPROMPT_H
#define ORDERCHECKINGPROMPT_H

#include "InvoicePart.h"
#include "tcmainwindow.h"

#include <QWidget>
#include <QCloseEvent>

namespace Ui {
class OrderCheckingPrompt;
}

class OrderCheckingPrompt : public QWidget
{
    Q_OBJECT

public:
    explicit OrderCheckingPrompt(const QString& userName, const QString& applyId, const QString& status, QWidget *parent = nullptr);
    ~OrderCheckingPrompt();

private:
    Ui::OrderCheckingPrompt *ui;

    QString applyId;
    QString userName;
    QString status;
    
    InvoicePart invoice;
    // 用于判断复核员是否是在审核计费员的计费申请
    // 1：审核计费申请
    // 0：查看船代已经同意的订单 为其打印发票
    // TODO 打印发票功能可以留到后面完成主线功能再做
    // TODO 复核员添加 了不予通过 和 打印发票功能还没有开始

    void initiate();
    void showCostInfo(QJsonObject& responseInfo);
    void produceExcelFile(QJsonObject& responseInfo);

    void closeEvent(QCloseEvent *event) override;//NOTE 这个关闭事件可以触发

public slots:
    void on_confirm_clicked();
    void on_deny_clicked();
    void on_getCheck_clicked();
    void on_cancel_clicked();
};

#endif // ORDERCHECKINGPROMPT_H
