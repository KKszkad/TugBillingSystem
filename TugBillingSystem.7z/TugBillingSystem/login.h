#ifndef LOGIN_H
#define LOGIN_H
#pragma once
#include <QWidget>
#include <QAbstractButton>
#include <QNetworkReply>

QT_BEGIN_NAMESPACE
namespace Ui { class Login; }
QT_END_NAMESPACE

class Login : public QWidget
{
    Q_OBJECT

signals:
    void loginSuccess();
    void loginFail();

private slots:
    void onRadioButtonClicked(QAbstractButton *button);
    void on_login_clicked();

public:
    Login(QWidget *parent = nullptr);
    ~Login();

private:
    QString userName;
    QString passWord;
    int userType;
    QString loginUrl = "/login";
    Ui::Login *ui;

    void loginCheck(QJsonObject &responseObj);

};
#endif // LOGIN_H
