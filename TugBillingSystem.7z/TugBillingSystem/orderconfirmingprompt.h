#ifndef ORDERCONFIRMINGPROMPT_H
#define ORDERCONFIRMINGPROMPT_H

#include <QWidget>

namespace Ui {
class OrderConfirmingPrompt;
}

class OrderConfirmingPrompt : public QWidget
{
    Q_OBJECT

public:
    explicit OrderConfirmingPrompt(const QString& applyId, QWidget *parent = nullptr);
    ~OrderConfirmingPrompt();

private:
    Ui::OrderConfirmingPrompt *ui;

    QString applyId;

    void initiate();
    void showCostInfo(QJsonObject& responseInfo);

    void closeEvent(QCloseEvent *event) override;

public slots:
    void on_agree_clicked();
    void on_disagree_clicked();
    void on_cancel_clicked();
};

#endif // ORDERCONFIRMINGPROMPT_H
