#ifndef COSTEDITINGPROMPT_H
#define COSTEDITINGPROMPT_H

#include <QWidget>

namespace Ui {
class CostEditingPrompt;
}

class CostEditingPrompt : public QWidget
{
    Q_OBJECT

public:
    explicit CostEditingPrompt(const QString& userName, const QString& applyId, QWidget *parent = nullptr);
    ~CostEditingPrompt();

private:
    Ui::CostEditingPrompt *ui;
    QString applyId;
    QString userName;

    void initiate();
    void showCostInfo(QJsonObject& responseInfo);
    void closeEvent(QCloseEvent *event) override;

public slots:
    void on_confirm_clicked();
    void on_cancel_clicked();
};

#endif // COSTEDITINGPROMPT_H
