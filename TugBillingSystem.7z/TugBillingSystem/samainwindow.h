#pragma once
#ifndef SAMAINWINDOW_H
#define SAMAINWINDOW_H

#include "TugApplication.h"

#include <QMainWindow>

namespace Ui {
class SAMainWindow;
}

class SAMainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void on_findShip_clicked();
    void on_confirmShip_clicked();
    void on_confirmWorks_clicked();
    void on_submitApplication_clicked();
public:
    QString userName;

    explicit SAMainWindow(const QString& userName, QWidget *parent = nullptr);
    ~SAMainWindow();

    void showShipInfo(QJsonObject &shipInfo);
    void showWorkInfo(QJsonObject &workInfo);
    void showPorts(QJsonObject &ports);

    //船代的数据展示部分
    void initOrdersTable();
    void agencyRequest();
    void showOrdersTable(QJsonObject& orderObj);

private:
    Ui::SAMainWindow *ui;
    QString shipInfoUrl = "/get_shipagent";

    int pageSize = 5;
    int totalPage;
    int currentPage = 1;

    TugApplication application;


public slots:
    // 船代的翻页按键
    void on_lastPage_clicked();
    void on_nextPage_clicked();
    void on_logOut_clicked();
};

#endif // SAMAINWINDOW_H
