package com.whut.jifeixitong.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whut.jifeixitong.entities.Area;
import org.springframework.stereotype.Repository;

@Repository
public interface AreaInfoMapper extends BaseMapper<Area> {
}
