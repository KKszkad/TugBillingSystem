package com.whut.jifeixitong.service;

import com.whut.jifeixitong.entities.AgentShip;


public interface AgentShipService {
    AgentShip get_AgentShipInfo(String zhName);
}
