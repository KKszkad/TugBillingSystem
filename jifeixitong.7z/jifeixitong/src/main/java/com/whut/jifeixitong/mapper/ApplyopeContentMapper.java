package com.whut.jifeixitong.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whut.jifeixitong.entities.ApplyContent;

public interface ApplyopeContentMapper extends BaseMapper<ApplyContent> {
}
